package com.ChildMonitoringSystem.managerapp.my_interface;

import com.ChildMonitoringSystem.managerapp.models.PhoneNameInbox;

public interface IClickItemMessage {
    void onClickItemMessage(PhoneNameInbox phoneNameInbox );
}
