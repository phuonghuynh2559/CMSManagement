package com.ChildMonitoringSystem.managerapp.my_interface;

import com.ChildMonitoringSystem.managerapp.models.Video;

public interface IClickVideoListener {
    void onClickItemVideo(Video video);
}
