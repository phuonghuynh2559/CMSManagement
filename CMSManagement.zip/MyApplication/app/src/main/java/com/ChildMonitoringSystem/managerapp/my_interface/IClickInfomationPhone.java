package com.ChildMonitoringSystem.managerapp.my_interface;


import com.ChildMonitoringSystem.managerapp.models.InfomationPhone;

public interface IClickInfomationPhone {
    void onClickGoToMenu(InfomationPhone phone);
}
