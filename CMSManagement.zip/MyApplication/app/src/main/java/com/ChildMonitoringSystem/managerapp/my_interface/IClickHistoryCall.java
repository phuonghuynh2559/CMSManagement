package com.ChildMonitoringSystem.managerapp.my_interface;

import com.ChildMonitoringSystem.managerapp.models.HistoryCall;

public interface IClickHistoryCall {
    void  onClickHistoryCall(HistoryCall historyCall);
}
