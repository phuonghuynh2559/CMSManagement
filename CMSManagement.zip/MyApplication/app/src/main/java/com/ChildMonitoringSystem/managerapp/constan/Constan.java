package com.ChildMonitoringSystem.managerapp.constan;

public class Constan {
    public static final String Action = "com.ChildMonitoringSystem.managerapp";
}
