package com.ChildMonitoringSystem.managerapp.my_interface;


import com.ChildMonitoringSystem.managerapp.models.Images;

public interface IClickImageListener {
    void  onClickItemImage(Images image);
}
