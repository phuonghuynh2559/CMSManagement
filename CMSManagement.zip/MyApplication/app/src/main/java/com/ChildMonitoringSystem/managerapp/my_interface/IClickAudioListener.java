package com.ChildMonitoringSystem.managerapp.my_interface;


import com.ChildMonitoringSystem.managerapp.models.Audio;

public interface IClickAudioListener {
    void  onClickAudio(Audio audio);
}
